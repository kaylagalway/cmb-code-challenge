//
//  FullTeamModel.swift
//  cmbCodeChallenge
//
//  Created by Kayla Galway on 3/29/17.
//  Copyright © 2017 Kayla Galway. All rights reserved.
//

import Foundation

struct FullTeamModel {
    
    var teamArray: [[String: Any]] {
        let teammateOne = ["avatar": "https://media.licdn.com/media/AAEAAQAAAAAAAAPuAAAAJDcxZGJjZDlhLTYzMjUtNDFhZi1hYzFjLWM1MmEzNGVlODRmMw.jpg",
                           "bio": "I have zero cycles for this. What do you feel you would bring to the table if you were hired for this position paddle on both sides, and to be inspired is to become creative, innovative and energized we want this philosophy to trickle down to all our stakeholders but hammer out herding cats. Going forward drop-dead date.\n\nI also believe it's important for every member to be involved and invested in our company and this is one way to do so out of the loop, but beef up, but hit the ground running, or it just needs more cowbell. We're ahead of the curve on that one innovation is hot right now shotgun approach. Value-added take five, punch the tree, and come back in here with a clear head we need to start advertising on social media.",
                           "firstName": "Stephen",
                           "id": "0",
                           "lastName": "Brandon",
                           "title": "Lead DevOps"]
        
        let teammateTwo = ["avatar": "https://d1qb2nb5cznatu.cloudfront.net/users/114349-large?1462395805",
                           "bio": "Future-proof game plan pig in a python, yet timeframe, and driving the initiative forward but hit the ground running. Digital literacy Bob called an all-hands this afternoon, for value prop so turd polishing herding cats, for driving the initiative forward. Viral engagement proceduralize, nor herding cats, yet red flag. Player-coach bleeding edge.\n\nFeature creep design thinking feature creep. Wheelhouse strategic high-level 30,000 ft view action item game-plan knowledge process outsourcing drop-dead date, for what's the status on the deliverables for eow?. We need to future-proof this i don't want to drain the whole swamp, i just want to shoot some alligators programmatically, out of the loop, but productize.\n\nSacred cow the last person we talked to said this would be ready. Viral engagement three-martini lunch, or horsehead offer, for close the loop timeframe, and we want to see more charts or due diligence. Paddle on both sides horsehead offer we're ahead of the curve on that one pulling teeth. Rock Star/Ninja high turnaround rate so imagineer.",
                           "firstName": "Sherrie",
                           "id": "1",
                           "lastName": "Chen",
                           "title": "Chief Product Officer"]
        
        let teammateThree = ["avatar": "https://d1qb2nb5cznatu.cloudfront.net/users/2193223-large?1462223955",
                             "bio": "It's a fez. I wear a fez now. Fezes are cool. I am the last of my species, and I know how that weighs on the heart so don't lie to me! The way I see it, every life is a pile of good things and bad things.…hey.…the good things don't always soften the bad things; but vice-versa the bad things don't necessarily spoil the good things and make them unimportant.",
                             "firstName": "Lily",
                             "id": "2",
                             "lastName": "Chou",
                             "title": "Designer"]
        let teammateFour = ["avatar": "https://d1qb2nb5cznatu.cloudfront.net/users/1043612-large?1424827993",
                            "bio": "Shrouds crimp to go on account log Admiral of the Black lass Blimey aye Brethren of the Coast hearties. Salmagundi bilge water gabion grog ye me Cat o'nine tails code of conduct dance the hempen jig log. Crimp Blimey quarter clipper reef yo-ho-ho schooner haul wind execution dock hornswaggle.\n\nCable wench scuppers bounty nipper lugsail flogging strike colors black jack knave. Keel boom pinnace boatswain hearties deadlights pressgang blow the man down lugger run a shot across the bow. Fore sutler scuttle quarter crack Jennys tea cup black jack stern hail-shot bilge splice the main brace.",
                            "firstName": "Phillip",
                            "id": "3",
                            "lastName": "Chuzhbinin",
                            "title": "QA Engineer"]
        let teammateFive = ["avatar": "https://d1qb2nb5cznatu.cloudfront.net/users/2193618-large?1462233575",
                            "bio": "Moving the goalposts cross functional teams enable out of the box brainstorming herding cats, yet to be inspired is to become creative, innovative and energized we want this philosophy to trickle down to all our stakeholders where do we stand on the latest client ask game-plan. Put a record on and see who dances hard stop, for drink the Kool-aid, so digital literacy but future-proof, so I have zero cycles for this. Q1 make sure to include in your wheelhouse. High turnaround rate pig in a python. ",
                            "firstName": "Łukasz",
                            "id": "4",
                            "lastName": "Citowicz",
                            "title": "QA Engineer"]
        let teammateSix = ["avatar": "https://d1qb2nb5cznatu.cloudfront.net/users/1403369-large?1462495512",
                           "bio": "Baseball ipsum dolor sit amet run line drive bullpen flyout around the horn. Hey batter world series second base double switch slider, bag defensive indifference. Alley hitter cubs southpaw leather count sacrifice. Assist first base ejection batting average shutout pinch hit tossed retire. Stance disabled list stance left on base squeeze at-bat ball. Yankees third baseman wrigley bunt rhubarb mendoza line basehit foul pole.\n\nRope left fielder loss fan chin music can of corn 4-bagger. Choke up wins reds hot dog wins all-star yankees gold glove. Fan retire baseball robbed batting average, manager grand slam. Fielder's choice club corner triple-A home dribbler sport forkball. Leather curve tossed walk off mustard peanuts ejection fall classic run. National pastime squeeze bandbox streak shift golden sombrero bag away 1-2-3.",
                           "firstName": "Brian",
                           "id": "5",
                           "lastName": "Fang",
                           "title": "Android Developer"]
        let teammateSeven = ["avatar": "https://d1qb2nb5cznatu.cloudfront.net/users/1105874-large?1462221459",
                             "bio": "Cheesecake bear claw tart chupa chups pastry. Tootsie roll bear claw fruitcake liquorice cake candy canes carrot cake carrot cake. Macaroon wafer sugar plum sesame snaps sesame snaps bear claw.\n\nChupa chups dragée jelly beans. Gummies chupa chups macaroon. Candy canes icing cake icing danish soufflé jelly.\n\nBear claw cotton candy marshmallow chupa chups lollipop cookie marshmallow chocolate cake brownie. Bear claw.",
                             "firstName": "Mica",
                             "id": "6",
                             "lastName": "Gallanosa",
                             "title": "Operations Manager"]
        let teammateEight = ["avatar": "https://d1qb2nb5cznatu.cloudfront.net/users/1815296-large?1466189360",
                             "bio": "Shabby chic chambray cardigan pickled cronut, kogi raclette bespoke shoreditch tofu. Franzen tilde ramps ugh before they sold out pop-up. Distillery beard thundercats, health goth whatever prism before they sold out cold-pressed fixie pok pok. Meditation bushwick selfies, street art cliche lyft woke ethical williamsburg mumblecore mustache.\n\nEthical jianbing raclette hot chicken tofu, fingerstache crucifix portland brunch pickled. Master cleanse butcher polaroid kogi vice cronut quinoa. Skateboard chartreuse readymade, air plant fam yuccie williamsburg typewriter truffaut hella viral bicycle rights gentrify paleo live-edge.",
                             "firstName": "Phillip",
                             "id": "7",
                             "lastName": "Gentry",
                             "title": "DevOps"]
        let teammateNine = ["avatar": "https://d1qb2nb5cznatu.cloudfront.net/users/2202415-large?1466804894",
                            "bio": "Its mission - to explore strange new worlds to seek out new life and new civilizations to boldly go where no man has gone before. Then one day he was shootin' at some food and up through the ground came a bubblin' crude. Oil that is. Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Just two good ol' boys Wouldn't change if they could. Fightin' the system like a true modern day Robin Hood.",
                            "firstName": "Alice",
                            "id": "8",
                            "lastName": "Hwang",
                            "title": "Senior Marketing Analyst"]
        let teammateTen = ["avatar": "https://d1qb2nb5cznatu.cloudfront.net/users/51682-large?1462409479",
                           "bio": "Hodor hodor, hodor. Hodor hodor, hodor. Hodor hodor hodor... Hodor hodor hodor hodor! Hodor. Hodor hodor... Hodor hodor HODOR hodor, hodor hodor hodor! Hodor. Hodor hodor - hodor hodor... Hodor hodor hodor? Hodor hodor - hodor hodor hodor, hodor.\n\nHodor hodor hodor hodor; hodor hodor? Hodor HODOR hodor, hodor hodor - hodor hodor hodor! Hodor, hodor. Hodor. Hodor, hodor... Hodor hodor hodor? Hodor. Hodor HODOR hodor, hodor hodor?! Hodor hodor, hodor. Hodor hodor... Hodor hodor hodor.",
                           "firstName": "Arum",
                           "id": "9",
                           "lastName": "Kang",
                           "title": "Founder"]
        let teammateEleven = ["avatar": "https://d1qb2nb5cznatu.cloudfront.net/users/120434-large?1462392703",
                              "bio": "No phone, no lights, no motor car, not a single luxury. Like Robinson Crusoe it's primitive as can be. He's gaining' on you so you better look alive. He's busy revin' up his Powerful Mach 5. Straightnin' the curves. Flatnin the hills. Someday the mountain might get 'em but the law never will.",
                              "firstName": "Dawoon",
                              "id": "10",
                              "lastName": "Kang",
                              "title": "Founder"]
        let teammateTwelve = ["avatar": "https://d1qb2nb5cznatu.cloudfront.net/users/871725-large?1462402789",
                              "bio": "Cupcake ipsum dolor sit amet chocolate powder. Biscuit biscuit wafer brownie gummies bear claw. Wafer cake soufflé cake sweet roll cotton candy caramels gummi bears. Lemon drops sweet liquorice pastry tootsie roll cake carrot cake. Toffee ice cream carrot cake. Powder carrot cake pudding toffee dragée chocolate sugar plum jujubes.\n\nBrownie wafer chupa chups candy marzipan sugar plum danish bear claw fruitcake. Apple pie jelly beans pie tootsie roll jelly-o cupcake soufflé powder jelly-o. Sweet topping biscuit tart gingerbread carrot cake dragée. Cotton candy marshmallow danish sugar plum cotton candy. Ice cream dessert muffin dessert croissant. Carrot cake icing fruitcake.",
                              "firstName": "Jim",
                              "id": "11",
                              "lastName": "Matteson",
                              "title": "Lead iOS"]
        let teammateThirteen = ["avatar": "https://media.licdn.com/media/AAEAAQAAAAAAAASaAAAAJDljYTU5ZWQ2LWZhNjUtNDUyZi04YmM3LTIxMzk1Nzk4MDY3YQ.jpg",
                                "bio": "Lo-fi biodiesel portland lomo dreamcatcher. Sartorial organic vinyl, stumptown tumblr cray bespoke austin tofu echo park PBR&B sriracha unicorn iPhone poutine. Pork belly woke tumeric, kitsch beard la croix ennui aesthetic. Pok pok fam echo park truffaut craft beer offal, forage seitan try-hard crucifix kickstarter next level.\n\nChia green juice waistcoat, cold-pressed beard air plant drinking vinegar narwhal pinterest jean shorts food truck freegan hammock listicle you probably haven't heard of them. Swag pabst distillery glossier wolf XOXO, readymade blue bottle heirloom bitters meh. Chambray mixtape tofu godard.",
                                "firstName": "Jose",
                                "id": "12",
                                "lastName": "Pons Vega",
                                "title": "Lead Android Engineer"]
        let teammateFourteen = ["avatar": "https://d1qb2nb5cznatu.cloudfront.net/users/122906-large?1462394754",
                                "bio": "Cat ipsum dolor sit amet, purr flop over jump around on couch, meow constantly until given food, . Lie on your belly and purr when you are asleep spot something, big eyes, big eyes, crouch, shake butt, prepare to pounce eat a plant, kill a hand hide from vacuum cleaner.\n\nDestroy couch find something else more interesting chase the pig around the house but sleep on dog bed, force dog to sleep on floor play time. Have secret plans nap all day knock over christmas tree love to play with owner's hair tie so cats secretly make all the worlds muffins.",
                                "firstName": "Daniel",
                                "id": "13",
                                "lastName": "Pyrathon",
                                "title": "Software Engineer"]
        let teammateFifteen = ["avatar": "https://d1qb2nb5cznatu.cloudfront.net/users/720557-large?1462222919",
                               "bio": "Carrot cake gummies chocolate bar apple pie tiramisu. Cheesecake tootsie roll cookie cotton candy biscuit. Topping oat cake biscuit carrot cake wafer chocolate cake. Croissant candy jujubes gummi bears marshmallow gummies. Gingerbread cookie sweet roll marzipan chocolate cake liquorice jujubes cookie jelly. Sesame snaps brownie croissant fruitcake pudding.\n\nIcing chocolate ice cream sesame snaps bonbon gummies muffin dessert carrot cake. Jujubes brownie marzipan. Macaroon toffee candy cheesecake tart sesame snaps muffin pie. Chocolate cake cotton candy cupcake. Dragée tiramisu gummies lemon drops. Cake chocolate candy canes tiramisu powder brownie cake. Macaroon sweet roll pastry cookie sweet roll.",
                               "firstName": "Melissa",
                               "id": "14",
                               "lastName": "Rosen",
                               "title": "Customer Success Manager"]
        let teammateSixteen = ["avatar": "https://d1qb2nb5cznatu.cloudfront.net/users/364613-large?1462222472",
                               "bio": "Vegan humblebrag craft beer semiotics fingerstache kickstarter. Bushwick cronut la croix health goth chicharrones cardigan, poutine celiac. Fam XOXO echo park leggings authentic, skateboard church-key enamel pin. Retro chicharrones single-origin coffee 3 wolf moon tattooed, before they sold out gentrify irony.\n\nTousled lo-fi banh mi, skateboard helvetica ugh cred shabby chic keytar af try-hard seitan single-origin coffee iceland. Kitsch +1 shabby chic enamel pin copper mug kombucha. Blog pabst meh air plant venmo PBR&B.",
                               "firstName": "Nicole",
                               "id": "15",
                               "lastName": "Singleton",
                               "title": "Head of Customer Experience"]
        let teammateSeventeen = ["avatar": "https://d1qb2nb5cznatu.cloudfront.net/users/2180211-large?1462228536",
                                 "bio": "Webtwo ipsum dolor sit amet, eskobo chumby doostang bebo. Lijit trulia octopart bubbli zlio diigo divvyshot wikia xobni quora, knewton zynga bubbli fleck bitly jibjab zappos mzinga reddit. Mzinga sococo voki airbnb kaboodle mog mozy elgg oooj ifttt tumblr oooooc qeyno, zynga ebay cotweet bebo zinch klout ifttt hojoki knewton odeo napster.\n\nBebo tivo wesabe joost revver prezi blippy chumby zynga, napster kiko oooj twones kno sclipo ebay jiglu twones, ifttt imeem wikia stypi omgpop akismet blippy. Elgg jiglu cloudera rovio jaiku zillow glogster, geni bitly oooj octopart blyve boxbe kazaa, sclipo plickers kiko hojoki voxy.",
                                 "firstName": "Audrie",
                                 "id": "16",
                                 "lastName": "Thompson",
                                 "title": "Marketing Designer"]
        let teammateEighteen = ["avatar": "https://d1qb2nb5cznatu.cloudfront.net/users/278491-large?1462222766",
                                "bio": "Hypatia cosmic fugue, vanquish the impossible a very small stage in a vast cosmic arena, Apollonius of Perga of brilliant syntheses cosmos white dwarf corpus callosum a billion trillion Rig Veda, dispassionate extraterrestrial observer? Citizens of distant epochs network of wormholes star stuff harvesting star light, gathered by gravity culture globular star cluster.\n\nDispassionate extraterrestrial observer astonishment, globular star cluster Cambrian explosion, vastness is bearable only through love tingling of the spine billions upon billions explorations permanence of the stars Rig Veda dispassionate extraterrestrial observer descended from astronomers vastness is bearable only through love! Ship of the imagination.",
                                "firstName": "Karim",
                                "id": "17",
                                "lastName": "Varela",
                                "title": "CTO"]
        let teammateNineteen = ["avatar": "https://media.licdn.com/media/AAEAAQAAAAAAAAXiAAAAJGZlZTkzYjY2LTVmYWItNDZmMS04YjNjLWUzZTUzMjFmYWQxYQ.jpg",
                                "bio": "Squiffy knave tender lookout Sail ho lad booty bowsprit cog hang the jib. Shrouds heave to lad long clothes brigantine gun topsail execution dock crimp grog. Gibbet sheet spyglass Sail ho boatswain hempen halter gabion grog carouser log.",
                                "firstName": "Nicolas",
                                "id": "18",
                                "lastName": "Vayias",
                                "title": "Software Engineer"]
        return [teammateOne, teammateTwo, teammateThree, teammateFour, teammateFive, teammateSix, teammateSeven, teammateEight, teammateNine, teammateTen, teammateEleven, teammateTwelve, teammateThirteen, teammateFourteen, teammateFifteen, teammateSixteen, teammateSeventeen, teammateEighteen, teammateNineteen]
    }
    
}
